// reload


function refresh(){
    window.location.reload();
    }
//sidebar



function openSlideMenu(){
    document.getElementById('side-menu').style.width='250px';
    //document.getElementById('content').style.marginLeft='250px';
    //document.getElementById('footer').style.marginLeft='250px';
}


function closeSlideMenu(){
    document.getElementById('side-menu').style.width='0';
   // document.getElementById('content').style.marginLeft='0';
    //document.getElementById('footer').style.marginLeft='0';
}

function goIG(){  
    window.location.href='https://www.instagram.com/wenyu_0327/';
}

function goFB(){ 
    window.location.href='https://www.facebook.com/profile.php?id=100003208639614';
}

function openTWT(){
    window.location.href='https://twitter.com/Caramel_Wen';
}